/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*****************************************************************************/


import java.util.*;

//calling the non-static variable from static method

class A{
    String name;
    static int age = 5;
    
    static void show( A obj){
        System.out.println(obj.name);
    }
}

class Main{
    public static void main(String[] args){
        System.out.println("hello world");
        
        A obj = new A();
        obj.name = "Utsav";
        
        System.out.println(obj.name);
        A.show(obj);
        
    }
}
