/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;

class Student implements Comparable<Student>
{
    int age;
    String name;
    
    public Student(int age, String name){
        this.age = age;
        this.name = name;
    }
    
    public String toString(){
        return "name :"+this.name+" age :"+this.age;
    }
    
    public int compareTo(Student that){
        return this.age > that.age ? 1 : -1;
    }
}

public class Main
{
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(12,21,34,54,11,72,13,14);
		//Collections.sort(list);
		
		System.out.println(list);
		
		Comparator<Integer> comp = (i,j) -> i%10 > j%10 ? 1 : -1;
		
		Collections.sort(list,comp);
		System.out.println(list);
		
		
		
		//Comparable 

		List<Student> studentList = new ArrayList<>();
		studentList.add (new Student(2,"utsav"));
		studentList.add (new Student(1,"arora"));
		
		Collections.sort(studentList);
		for(Student stud : studentList){
		    System.out.println(stud);
		}
	}
}
