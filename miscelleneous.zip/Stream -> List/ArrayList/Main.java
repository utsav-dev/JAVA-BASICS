/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
import java.util.stream.*;


public class Main
{
    public static void display(List list){
        System.out.println(list);
    }
	public static void main(String[] args) {
		System.out.println("Hello World");
		List<Integer> list = Arrays.asList(1,2);
		Stream<Integer> str = list.stream(); // or  Stream.of(1,4,7);
		//stream to list
		List<Integer> listStream = str.collect(Collectors.toList()); //Stream.toList(str);//JAVA 16 
		//list to ArrayList
		ArrayList<Integer> arr = new ArrayList<>(listStream);
		
		display(listStream);
	}
}
