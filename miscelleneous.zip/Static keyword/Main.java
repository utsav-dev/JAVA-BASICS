/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class Test {
    static String name;
    int age;
    
    void display(){
        /*all variables can be used in a non-static method
        */
        
        System.out.println("name" + ":" + name);
        
        System.out.println("age" + ":" + age);
        
    }
    
    
    /*
     * STATIC METHOD
     */
    
    public static void show(){
        /*only static variables can be used inside a static method
        else it will throw error
        */
        
        System.out.println("name" + ":" + name);
        
        System.out.println("age" + ":" + age);//throw err
        
        
    }
    
    
        /*but non-static variables can be used inside a static method 
        in an indirect way
        pass a obj of this class as a parameter and using that obj access the variables
        */
        
        public static void showStatic(Test testObj){
            System.out.println("name" + ":" + testObj.name);
        
            System.out.println("age" + ":" + testObj.age);//no err
        
            
        }
        
        /*
         * STATIC BLOCK
         */
         
         /*
          * in order to initialize the static variables 
          we can do that inn the constructor
          but in that way the static variables will be initialized 
          everytime we create an obj
          
          So we use a static block to initialize the static variables.
          */
          
          static{
              name="Utsav";
          }
          
          /*
           * NOTE : STATIC block will be called even before the constructors
           
           ****REASON
           when we create an obj => the class is loaded and then the obj is instantiated
           
           so the class loads first therefore the static block is called first
           
           
           class is loaded only once as the JVM loads the class inn the class loader
           */
           
           
           /*
            * we cant load a class until an obj is created
            so if we want to load the class and call the static block
            
            we can achieve this using
            Class class
            Class is a special class which gives a method 'forName'
            it will load the class usinng the class loader
            
            SYNTAX : Class.forName("Test");
            */
}
class Main {
public static void main(String[] args){
    
    Test obj = new Test();
    
    Test.showStatic(obj);
    
}
}
