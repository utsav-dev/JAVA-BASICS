/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
interface A{
    default void display(){ System.out.println("In A"); }
}
interface B{
    void display(); // same name methods cant be default on both interfaces -> error: types A and B are incompatible;
}
class Test implements A, B {
    public void display(){
        
    }
}
public class Main
{
	public static void main(String[] args) {
		Test testObj = new Test();
		testObj.display();
	}
}
