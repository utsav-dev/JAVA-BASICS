/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class A {
    public void displayOuter(){
        System.out.println("In outer");
    }
    
    class B{
        public void displayInner(){
            System.out.println("In inner");
        }
    }
    
}
public class Main
{
	public static void main(String[] args) {
		A a = new A();
		a.displayOuter();
		
		A.B b = a.new B(); // for the non-static inner class
		b.displayInner();
		
		
		/* for the static inner class
		 * 
		 A.B obj = new A.B();
		 obj.displayInner();
		 */
	}
}
