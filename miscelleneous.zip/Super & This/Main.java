/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class A{
    public A(){
        System.out.println("in A");
    } 
     public A(int n){
        System.out.println("in A"+ n);
    } 
}

class B{
    public B(){
        // in every constructor there is a default statement => super();
        super();
        System.out.println("in B");
    } 
    
    public B(int n){
            super(n);
            //this(); to invoke the same class constructor
        // in every constructor there is a default statement => super();
        System.out.println("in B"+ n);
    } 
}
public class Main
{
	public static void main(String[] args) {
		B b = new B(5);
	}
}
