/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


/*
 * Either use the lambda expression with Runnable interface
 OR use the Test class implements Runnable way 
 */
 
 
class Test implements Runnable
{
  public void run ()
  {
    for (int i = 0; i < 5; i++)
      {
	System.out.println ("Hi" + i);
      }
  }
}
  public class Main
  {
    public static void main (String[]args)
    {


      Runnable obj1 = ()->{
	for (int i = 0; i < 5; i++)
	  {
	    System.out.println ("Hi" + i);


	    try
	    {
	      Thread.sleep (2);
	    } catch (Exception e)
	    {
	    }

	  }
      };

      Runnable obj2 = ()->{
	for (int i = 0; i < 5; i++)
	  {
	    System.out.println ("Hello" + i);


	    try
	    {
	      Thread.sleep (2);
	    } catch (Exception e)
	    {
	    }

	  }
      };

      Thread t1 = new Thread (obj1);	//use the overloaded constructor of the thread class
      Thread t2 = new Thread (obj2);

      t1.start ();
      t2.start ();
    }
  }
