/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

class A extends Thread
{
  public void run ()
  {
    for (int i = 0; i < 10; i++)
      {
	System.out.println ("HI" + i);


	try
	{
	  Thread.sleep (10);
	} catch (InterruptedException e)
	{
	}
      }
  }
}

class B extends Thread
{
  public void run ()
  {
    for (int i = 0; i < 10; i++)
      {
	System.out.println ("HELLO" + i);


	try
	{
	  Thread.sleep (10);
	}
	catch (InterruptedException e)
	{
	}
      }
  }
}


public class Main
{
  public static void main (String[]args)
  {



    A obj1 = new A ();
    B obj2 = new B ();


      System.out.println (obj1.getPriority ());	// getter
      obj2.setPriority (Thread.MAX_PRIORITY);	// setter
      System.out.println (obj2.getPriority ());

      obj1.start ();
      obj2.start ();
  }
}



/*
 * Priorty ranges from 1 to 10
 
 
 */
