/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class A extends Thread {
    public void run(){
        for(int i = 0; i < 10; i++)
            System.out.println("HI"+i);
    }
}

class B extends Thread{
    public void run(){
        for(int i = 0; i < 10; i++)
            System.out.println("HELLO"+i);
    }
}

public class Main
{
	public static void main(String[] args) {


        A obj1 = new A();
        B obj2 = new B();
        
        obj1.start();
        obj2.start ();
	}
}


/*
 * Definition : the smallest unit of a task is Thread
 
 When we want to execute these two objs simultaneously
 then we have to convert these classes innto a thread classes
 
 
 call the start method 
 which will call the run method in the new thread classes
 
 os will decide which thread to execute with the help of a scheduler
 
 
 */
