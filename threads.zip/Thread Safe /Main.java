/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Counter
{
  int count;
  public synchronized void incr () // synchronized will make sure that this method will be called only by a single thread 
  {
    count++;
  }
}

public class Main
{
  public static void main (String[]args) throws InterruptedException
  {
    System.out.println ("Hello World");

    Counter c = new Counter ();

    Runnable obj1 = ()->{
      for (int i = 0; i < 5; i++)
	c.incr ();


    };

    Runnable obj2 = ()->{
      for (int i = 0; i < 5; i++)
	c.incr ();

    };

    Thread t1 = new Thread (obj1);
    Thread t2 = new Thread (obj2);

    t1.start ();
    t2.start ();

    t1.join (); // join method makes the main method wait for both the threads to complete and come back
    t2.join ();

    System.out.println (c.count);

  }
}


