/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

/*
 * to call a catch block on demand we use THROW keyword.
 */
public class Main
{
  public static void main (String[]args)
  {
    int j = 20;
      try
    {
          if (j == 20)
    	{
    	  throw new ArithmeticException ("Utsav");
    	}
    }
    catch (ArithmeticException ae)
    {
      j = 100;
      System.out.println ("j is 100" + ae);
    }

    System.out.println (j);
  }
}
