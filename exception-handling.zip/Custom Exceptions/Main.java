/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class TestException extends Exception{
     public TestException(String e){
        super(e); // it will throw the custom string also using constructor of Exception class;
     }
}
public class Main
{
	public static void main(String[] args) {
		try{
		    throw new TestException("TestException is thrown");
		}
		catch(TestException te){
		    System.out.println("Custom Exception    "+te); //te will print the name of this class i.e TestException if we dont call super()
		}
	}
}
