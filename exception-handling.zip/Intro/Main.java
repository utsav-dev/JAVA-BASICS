/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

/*
 * run time errors are known as Exceptions
 
 Errors are of 3 types : Compile time errors, Run time errors, Logical errors.
 */

class Main
{
  public static void main (String[]args)
  {
    int i = 0;
    int j = 18;
    int[] nums = new int[5];

      try
    {
      System.out.println (j / i);
      System.out.println (nums[5]);
    } catch (ArithmeticException ae)
    {
    System.out.println (ae);
        
    } catch (ArrayIndexOutOfBoundsException aie)
    {
      System.out.println (aie);
    }
    catch (Exception e)
    {
      System.out.println (e);
    }
  }
}
