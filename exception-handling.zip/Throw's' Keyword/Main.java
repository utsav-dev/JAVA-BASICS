/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Test{
    public void error() throws ClassNotFoundException{
        Class.forName("Demo");
    }
}

class Demo{
    static{
        System.out.println("Demo class is loaded now");
    }
}
public class Main
{
	public static void main(String[] args) {
		Test testObj = new Test();
		try{
		    testObj.error();
		} catch(ClassNotFoundException e){
		    e.printStackTrace();
		}
		
	}
}
