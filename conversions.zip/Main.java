/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class Main{
    public static void main(String[] args){
        
        
    //1. String -> int & Integer
    
    String age = "50";
    int i = Integer.parseInt(age);
    Integer ig = Integer.valueOf(age);
    
    
    
    // int to String
    
    int b = 10;
    String sb = String.valueOf(i);
    sb = Integer.toString(i);
    
    
    
    // long to String
    long l=Long.parseLong("200");
    l = Long.valueOf("10");
    System.out.println(l);
    
    
    //String to Long
    String sl = String.valueOf();
    sl = Long.toString();
    
    
    }
}
